package com.diazariel.apirest.entity;

public enum Provider {
	LOCAL, GOOGLE, FACEBOOK, GITHUB
}
